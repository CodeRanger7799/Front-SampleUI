import React,{Component} from 'react'
import {Route} from 'react-router-dom'
import Title from './Title'
import Test from './TestmerchantSignup'
import Success from './Success'
import Error from './Error'
import MerchantSignup from './MerchantSignup'
import Dashboard from './Dashboard'
import Login from './Login'
import Logout from './Logout'

 


class Main extends Component{

    MerchantAdded(merchant)
    {
        console.log(merchant)
    }


    render()
    {
        return(
            <div>
                <Route path = '/MerchantSignup' render = {
                    ({history}) => {
                        return(
                        <div>
                            <Title title={'Add Merchant'}/>
                            <MerchantSignup merchanntAdd = {
                                (merchant) =>{
                                    this.MerchantAdded(merchant)
                                    history.push('/Success')
                                }
                            }   merchantCancel = {
                                () => {
                                    history.push('/Dashboard')
                                }
                            }/>
                            </div>)
                    }
                }/>

                <Route path='/Success' render = {
                    () => {
                        return (
                        <div>
                        <Title title={'Congratulations! Merchant Added'}/>
                        <Success />
                        </div>)
                    }
                }/>

                <Route path='/Error' render = {
                    () => {
                        return (
                            <div>
                            <Title title = {'Sorry, Some Unexpected Error Occured.'} />
                            <Error />
                            </div>
                        )
                    }
                } />

                <Route path= '/Test' render = {
                 ({history}) => {
                     return(
                         <div>
                             <Title title={'Add Merchant'}/>
                             <Test merchanntAdd = {
                                 (p) =>{
                                     this.MerchantAdded(p)
                                     history.push('/Success')
                                 }
                             }/>
                             </div>
                     )
                 }
                }/>

                <Route path = '/Dashboard' render =
                 {
                     ({history}) => {
                        return (
                            <div>
                                <Dashboard {...this.props} history = {history} />
                                </div>
                        )
                     }
                 }/>
                <Route exact path= '/' render = {
                ({history}) => {
                    return (
                        <Login loginSuccess = {
                        () => {
                             history.push('/Dashboard')
                        }
                        }
                        />
                    )
                }    
                }
                />

                <Route path='/Logout' render = {
                () => {
                    return (<div>
                         <Title title = {'Logout Success'} />
                         <Logout />
                        </div>)
                   
                }
                }/>
            </div>
        )
    }
}

export default Main

