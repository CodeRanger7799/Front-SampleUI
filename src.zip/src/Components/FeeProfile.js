import React from 'react'

function FeeProfile(props){
    return (
        <div>
            <div className='container-menu-options'>
                <p> Fee Profile Dashboard</p>
            </div>
        </div>
    )
}

export default FeeProfile