import React from 'react'
import {Link} from 'react-router-dom'

function Logout(props){
    return (
        <div>
            <div className = 'logout-body'>
                <button className= 'success-btn'> </button>
            </div>
                <Link className = 'logout-icon' to = '/'> </Link>
                <p className='logout-icon-paragraph'><b> Please click on above icon to login again. </b></p>
        </div>
    )

}

export default Logout