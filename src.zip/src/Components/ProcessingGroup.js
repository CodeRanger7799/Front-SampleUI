import React from 'react'

function ProcessingGroup(props){
    return (
        <div>
             <div className='container-menu-options'>
                <p> Processing Group Dashboard</p>
            </div>
        </div>
    )
}

export default ProcessingGroup