import React from 'react'

function BillingProfile(props){
    

    return (
        <div>
            <div className='container-menu-options'>
                <p> Billing Profile Dashboard</p>
            </div>
        </div>
    )
}

export default BillingProfile