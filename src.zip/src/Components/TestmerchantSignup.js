import React, {useState} from 'react'
import 'react-phone-number-input/style.css'
import PhoneInput from 'react-phone-number-input'
import { CountryDropdown, RegionDropdown} from 'react-country-region-selector';
import {useForm} from 'react-hook-form'
import ErrorMessage from './ErrorMessage'

// CATID: Card Acceptor Tax ID
// MCC: Merchant Category Code
// MTA: Max Transaction Amount
// SMURL: Sub-Merchant URL
// SMN: Sub-Merchant Name


function Test(props){

    // To create merchant object from the input fields by user. The React-Hook-form is creating an object via register into data object.
    const handleForm = data =>{
    const merchant = {
            orgId: data.orgId,
            shortName: data.shortName,
            merchantName: data.merchantName,
            legalName: data.legalName,
            streetAddress: data.streetAddress,
            phone: phone,
            country: country,
            region: region,
            city: data.city,
            postalCode: data.postalCode,
            url: data.URL,
            cardAcceptorTaxId: data.CATID,
            merchantCategoryCode: data.MCC,
            maxTransactionAmount: data.MTA,
            subMerchantUrl: data.SMURL,
            subMerchantName: data.SMN
        }
        props.merchanntAdd(merchant)
    }

    const {register,handleSubmit,errors,formState: { isSubmitting }} = useForm();

        const [phone, setPhone] = useState()
        const [country, setCountry] = useState()
        const [region, setRegion] = useState()

        return (
            <div className = 'form'>
                <form onSubmit= {handleSubmit(handleForm)}>
                <label htmlFor="orgId"><b>Organisation Id</b></label>
                    <select name="orgId" ref={register({required:true})}>
                        <option value = "" disabled selected>Select One...</option>
                         <option value="4:Tid Merchant 10"> 4:Tid Merchant 10 </option>
                         <option value="6:Tid Merchant 11">6:Tid Merchant 11</option>
                         <option value="8:Tid Merchant 12">8:Tid Merchant 12</option>
                         <option value="A merchant-only organisation:25">A merchant-only organisation:25</option>
                         <option value="Amazon Funding Merchant : 103">Amazon Funding Merchant : 103</option>
                         <option value="Amazon : 9999">Amazon : 9999</option>
                         <option value="Auto Account Update : 1250">Auto Account Update : 1250</option>
                    </select>
                    <ErrorMessage error={errors.orgId} />
                <label htmlFor="shortName"><b>Short Name</b></label>
                    <input type= 'text' placeholder = 'Short Name' name = 'shortName' ref={register({required:true})}/>
                    <ErrorMessage error={errors.shortName} />
                <label htmlFor="merchantName"><b>Merchant Name</b></label>
                    <input type='text' placeholder = 'Merchant Name' name = 'merchantName' ref={register({required:true, minLength:2})}/>
                    <ErrorMessage error={errors.merchantName} />
                <label htmlFor="LegalName"><b>Legal Name</b></label>
                    <input type='text' placeholder = 'Legal Name' name = 'legalName' ref={register({required:true, minLength:2})}/>
                    <ErrorMessage error={errors.legalName} />
                <label htmlFor="Street Address"><b>Street Address</b></label>
                    <input type='text' placeholder = 'Street Address' name = 'streetAddress' ref={register({required:true})}/>
                    <ErrorMessage error={errors.streetAddress} />
                <label htmlFor="country"><b>Country</b></label>
                <CountryDropdown value={country} onChange={setCountry} name='country' />
                <label htmlFor="state"><b>State</b></label>
                <RegionDropdown country={country} value={region} onChange={setRegion} name='region' />
                <label htmlFor="city"><b>City</b></label>
                    <input type='text' placeholder = 'City' name = 'city' ref={register({required:true})}/>
                    <ErrorMessage error={errors.city}/>
                <label htmlFor="postalCode"><b>Postal Code</b></label>
                    <input type='text' placeholder = 'Postal Code' name = 'postalCode' ref = {register({required:true})}/>
                    <ErrorMessage error={errors.postalCode} />
                <PhoneInput className='phn' international placeholder="Enter phone number" value={phone} onChange={setPhone}/> 
                <label htmlFor="URL"><b>URL</b></label>
                    <input type='text' placeholder = 'URL' name = 'URL' ref={register({required:true, pattern: /^(https?|chrome):\/\/[^\s$.?#].[^\s]*$/gm })}/>
                    <ErrorMessage error={errors.URL} />
                <label htmlFor="CATID"><b>Card Acceptor Tax ID</b></label>
                    <input type='text' placeholder = 'CAT ID' name = 'CATID' ref = {register({required:true})}/> 
                    <ErrorMessage error={errors.CATID} />     
                <label htmlFor="MCC"><b>Merchant Category Code</b></label>
                    <select name="MCC" ref = {register({required:true})}>
                        <option value = "" disabled selected>Select One...</option>
                         <option value="0742 : Medical: Veterinary services"> 0742 : Medical: Veterinary services </option>
                         <option value="0763 : Telecom, Utilities & Trades : Agricultural cooperatives">0763 : Telecom, Utilities & Trades : Agricultural cooperatives</option>
                         <option value="0780 : Telecom, Utilities & Trades : Landscaping and horticultural services">0780 : Telecom, Utilities & Trades : Landscaping and horticultural services</option>
                         <option value="1111 : Litle : LITLE">1111 : Litle : LITLE</option>
                         <option value="1520 : Telecom, Utilities & Trades : General contractors - residential and commercial">1520 : Telecom, Utilities & Trades : General contractors - residential and commercial</option>
                         <option value="1711 : Telecom, Utilities & Trades : Heating, plumbing and air-conditioning contractors">1711 : Telecom, Utilities & Trades : Heating, plumbing and air-conditioning contractors</option>
                         <option value="1731 : Telecom, Utilities & Trades : Electrical Contractors">1731 : Telecom, Utilities & Trades : Electrical Contractors</option>
                    </select>
                    <ErrorMessage error={errors.MCC} />                                    
                <label htmlFor="MTA"><b>Max Transaction Amount</b></label>
                    <input type='text' placeholder = 'Max Transaction Amount' name = 'MTA' ref={register({required:true})}/>
                    <ErrorMessage error={errors.MTA} />
                <label htmlFor="SMURL"><b>Sub-merchant URL</b></label>
                    <input type='text' placeholder = 'Sub-merchant URL' name = 'SMURL' ref={register({required:true})}/>
                    <ErrorMessage error={errors.SMURL} />
                <label htmlFor="SMN"><b>Sub Merchant Name</b></label>
                    <input type='text' placeholder = 'Sub Merchant Name' name = 'SMN' ref={register({required:true})}/>
                    <ErrorMessage error={errors.SMN} />
                    <button disabled={isSubmitting} type='submit'> Submit </button>
                </form>
            </div>
        )
    }


export default Test
