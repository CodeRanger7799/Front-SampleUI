import React from 'react'
import {Link} from 'react-router-dom'


function Success(){
    return (
        <div>
        <div className = 'success-body'>
            <button className= 'success-btn'> </button>
        </div>
        <Link className = 'add-icon' to = '/'> </Link>
        <p className='add-icon-paragraph'><b> Please click on above icon to add another Merchant </b></p>
        </div>
    )
}

export default Success