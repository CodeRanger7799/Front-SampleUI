import React from 'react'
import {Link} from 'react-router-dom'


function Merchant(props){

  const handleSearch = () =>
  {
    console.log(document.getElementById('searchParameter').value)
  }

    return (
    <div>
     <div className='container-menu-options'>
         <p> Merchant Dashboard</p>
     </div>
     <div class="navbar-merchant">
        <select name='selectParam'>
        <option value = 'Merchant Id/ Org Id'>Merchant Id/Org Id</option>
        <option value = 'Merchant Id/ Org Id'>Merchant Id/Org Id</option>
        <option value = 'Merchant Id/ Org Id'>Merchant Id/Org Id</option>
        </select>
     <input type="text" placeholder="Search.." name='searchParameter' id='searchParameter'/>
     <button type="submit" onClick = {handleSearch}><i class="fa fa-search"></i></button>  
     <Link to="/" className='navbar-merchant-Link'>Comprehensive View</Link>
     <Link to="/MerchantSignup" className='navbar-merchant-Link'>Add</Link>
     <Link to="/" className='navbar-merchant-Link'>Shallow Copy</Link>
     <Link to="/" className='navbar-merchant-Link'>Edit Basic Details </Link>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Network Profiles
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Payment Methods
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Presenter Relationships
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
     <div class="dropdown-menu">
       <button class="dropbtn-menu">Features
         <i class="fa fa-caret-down"></i>
       </button>
       <div class="dropdown-content-menu">
         <Link to="/" className='navbar-merchant-Link'>Link 1</Link>
         <Link to="/" className='navbar-merchant-Link'>Link 2 </Link>
         <Link to="/" className='navbar-merchant-Link'>Link 3</Link>
       </div>
     </div>
   </div>
   </div>
    )
}

export default Merchant