import React from 'react'

function ErrorMessage(props){
    if (props.error) {
        switch (props.error.type) {
          case "required":
            return <p className='error-msg'>This is required</p>;
          case "minLength":
            return <p> Minmium 2 charcaters is required</p>;
          case "pattern":
            return <p className='error-msg'>Enter a valid URL</p>;
          case "min":
            return <p>Minmium </p>;
          case "validate":
            return <p>To be implemented</p>;
          default:
            return null;
        }
      }
    
      return null;
}

export default ErrorMessage