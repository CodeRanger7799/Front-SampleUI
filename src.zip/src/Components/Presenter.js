import React from 'react'

function Presenter(props){
    return (
        <div>
            <div className='container-menu-options'>
                <p> Presenter Dashboard</p>
            </div>
        </div>
    )
}

export default Presenter